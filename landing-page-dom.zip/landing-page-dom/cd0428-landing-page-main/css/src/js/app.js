const mobileMenu = document.querySelector('.mobile-menu')
mobileMenu.addEventListener('click',()=>{
    document.querySelector('.menu').classList.toggle('show')
})