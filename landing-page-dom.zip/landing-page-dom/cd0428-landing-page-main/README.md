# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.



# Udacity | Landing Page Project

  

**Version 1.0.0**


Main goal on this Project is about creating a Navigation Floating Bar that moves Dynamically with JavaScript via the DOM .
  

------------------------------------------------------
------------------------------------------------------
------------------------------------------------------

  

## Table of Contents

  

- [Project Title](#Udacity-|-Landing-Page-Project)

- [Instructions](#instructions)

- [Table of contents](#table-of-contents)

- [Installation](#installation)

- [Usage](#usage)

- [Development](#development)

- [Contribute](#contribute)

- [License & Copyright](#License-&-Copyright)

  

------------------------------------------------------
------------------------------------------------------
------------------------------------------------------

  

## Instructions

[(Back to top)](#table-of-contents)

  

The project had HTML and CSS styling that done by me, That was done by making Some modifications to HTML and CSS Styling and Creating a whole JS File to make the Project Interactive.

  

------------------------------------------------------
------------------------------------------------------
------------------------------------------------------

  

## Installation

[(Back to top)](#table-of-contents)

  
You can Install this project to your PC using clone the repo to your github account then Download It as a ZIP File to your PC.

or Clone it using GIT ````git clone````.

  

------------------------------------------------------
------------------------------------------------------
------------------------------------------------------

  

# Usage

[(Back to top)](#table-of-contents)

  

After The Installation you can now use the project files by UnZip the file and open it on any Code Text Editor (VS Code).

  

------------------------------------------------------
------------------------------------------------------
------------------------------------------------------

  

# Development

[(Back to top)](#table-of-contents)

  

````JS Version: ES2015/ES6.````

  

````JS Standard: ESlint.````

  

#### The Project Contains Four Files :

#### css / src / styles /

- all files inside

####  index.html

#### js /

- app.js

####  README.md

  

##### Each file contains it's modifications and comment above each step of modify.

- In CSS I just used my last Blog Project design which it stands on the requirements.


- In HTML File I used my Blog project design and added what needed => Floating Navbar and Form.
  

- JS I created from scratch and added some functions to make stuff work as expected:

------------------------------------------------------
------------------------------------------------------
------------------------------------------------------

# Contribute

[(Back to top)](#table-of-contents)

  
**- Udacity**


------------------------------------------------------
------------------------------------------------------
------------------------------------------------------

# License & Copyright

[(Back to top)](#table-of-contents)

  

**© Udacity - Modified By Slim Ashkar.**
